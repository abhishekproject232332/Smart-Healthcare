/* ============================================================
   Smart Healthcare — script.js
   ============================================================ */

// ─── Doctor Data ────────────────────────────────────────────
const doctors = [
  { id: 1, name: "Dr. Raj Sharma",     specialty: "Cardiologist",      experience: "10 years", location: "Delhi",     rating: 4.6, fee: "₹800",  avail: "Mon–Sat" },
  { id: 2, name: "Dr. Priya Mehta",    specialty: "Dermatologist",     experience: "8 years",  location: "Mumbai",    rating: 4.8, fee: "₹600",  avail: "Mon–Fri" },
  { id: 3, name: "Dr. Arjun Nair",     specialty: "General Physician", experience: "12 years", location: "Bangalore", rating: 4.5, fee: "₹400",  avail: "All Days" },
  { id: 4, name: "Dr. Sneha Reddy",    specialty: "Dentist",           experience: "6 years",  location: "Hyderabad", rating: 4.7, fee: "₹500",  avail: "Tue–Sun" },
  { id: 5, name: "Dr. Vikram Patel",   specialty: "Orthopedist",       experience: "15 years", location: "Ahmedabad", rating: 4.9, fee: "₹1000", avail: "Mon–Sat" },
  { id: 6, name: "Dr. Ananya Singh",   specialty: "Pediatrician",      experience: "9 years",  location: "Chennai",   rating: 4.6, fee: "₹550",  avail: "All Days" },
  { id: 7, name: "Dr. Rohit Kumar",    specialty: "Neurologist",       experience: "14 years", location: "Pune",      rating: 4.8, fee: "₹1200", avail: "Mon–Fri" },
  { id: 8, name: "Dr. Meena Iyer",     specialty: "Gynecologist",      experience: "11 years", location: "Kolkata",   rating: 4.7, fee: "₹700",  avail: "Mon–Sat" },
  { id: 9, name: "Dr. Suresh Gupta",   specialty: "Cardiologist",      experience: "18 years", location: "Delhi",     rating: 4.9, fee: "₹1500", avail: "Mon–Fri" },
  { id: 10, name: "Dr. Kavita Rao",    specialty: "Ophthalmologist",   experience: "7 years",  location: "Jaipur",    rating: 4.5, fee: "₹600",  avail: "Tue–Sun" },
  { id: 11, name: "Dr. Anil Desai",    specialty: "Dentist",           experience: "5 years",  location: "Surat",     rating: 4.4, fee: "₹450",  avail: "Mon–Sat" },
  { id: 12, name: "Dr. Neha Kapoor",   specialty: "Dermatologist",     experience: "10 years", location: "Delhi",     rating: 4.8, fee: "₹750",  avail: "Mon–Fri" },
];

// ─── Specialty icon / colour map ────────────────────────────
const specialtyMeta = {
  "Cardiologist":      { icon: "🫀", color: "#fee2e2", textColor: "#991b1b" },
  "Dermatologist":     { icon: "✨", color: "#fef3c7", textColor: "#92400e" },
  "General Physician": { icon: "🩺", color: "#d1fae5", textColor: "#065f46" },
  "Dentist":           { icon: "🦷", color: "#e0f2fe", textColor: "#075985" },
  "Orthopedist":       { icon: "🦴", color: "#f3e8ff", textColor: "#6b21a8" },
  "Pediatrician":      { icon: "👶", color: "#fce7f3", textColor: "#9d174d" },
  "Neurologist":       { icon: "🧠", color: "#ede9fe", textColor: "#4c1d95" },
  "Gynecologist":      { icon: "💜", color: "#fdf2f8", textColor: "#86198f" },
  "Ophthalmologist":   { icon: "👁️", color: "#ecfdf5", textColor: "#065f46" },
};

function getMeta(specialty) {
  return specialtyMeta[specialty] || { icon: "🏥", color: "#e2e8f0", textColor: "#334155" };
}

function starsHtml(rating) {
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5 ? 1 : 0;
  const empty = 5 - full - half;
  return '★'.repeat(full) + (half ? '½' : '') + '☆'.repeat(empty);
}

function getInitials(name) {
  return name.replace("Dr. ", "").split(" ").map(w => w[0]).join("").slice(0, 2);
}

// ─── Render Doctor Cards ─────────────────────────────────────
function renderDoctors(list, containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  if (list.length === 0) {
    container.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
      <div class="empty-icon">🔍</div>
      <p>No doctors found matching your search.</p>
    </div>`;
    return;
  }

  container.innerHTML = list.map((doc, i) => {
    const meta = getMeta(doc.specialty);
    return `
    <div class="doctor-card fade-up delay-${(i % 4) + 1}" data-id="${doc.id}">
      <div class="doctor-card-header">
        <div class="doctor-avatar" style="background:${meta.color}; color:${meta.textColor}">
          ${getInitials(doc.name)}
        </div>
        <div class="doctor-info">
          <h3>${doc.name}</h3>
          <div class="doctor-specialty">${meta.icon} ${doc.specialty}</div>
        </div>
      </div>
      <div class="doctor-card-body">
        <div class="doctor-meta">
          <div class="meta-item"><span class="ico">📍</span>${doc.location}</div>
          <div class="meta-item"><span class="ico">⏱️</span>${doc.experience} experience</div>
          <div class="meta-item"><span class="ico">💰</span>Consultation: ${doc.fee}</div>
          <div class="meta-item"><span class="ico">📅</span>Available: ${doc.avail}</div>
        </div>
        <div class="rating-stars">
          <span class="star">${starsHtml(doc.rating)}</span>
          <span class="rating-val">${doc.rating}</span>
        </div>
      </div>
      <div class="doctor-card-footer">
        <a href="appointment.html?doctor=${encodeURIComponent(doc.name)}" class="btn btn-blue" style="width:100%; justify-content:center">
          Book Appointment →
        </a>
      </div>
    </div>`;
  }).join('');
}

// ─── Populate Doctor <select> ────────────────────────────────
function populateDoctorSelect() {
  const sel = document.getElementById('selectDoctor');
  if (!sel) return;
  sel.innerHTML = '<option value="">— Choose a doctor —</option>' +
    doctors.map(d => `<option value="${d.name}">${d.name} (${d.specialty})</option>`).join('');

  // Pre-select from URL param
  const params = new URLSearchParams(window.location.search);
  const pre = params.get('doctor');
  if (pre) sel.value = pre;
}

// ─── LocalStorage Helpers ────────────────────────────────────
function getAppointments() {
  try { return JSON.parse(localStorage.getItem('smart_health_appts') || '[]'); }
  catch { return []; }
}

function saveAppointments(arr) {
  localStorage.setItem('smart_health_appts', JSON.stringify(arr));
}

// ─── Book Appointment ────────────────────────────────────────
function setupBookingForm() {
  const form = document.getElementById('bookingForm');
  if (!form) return;

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    const appt = {
      id:      Date.now(),
      patient: form.patientName.value.trim(),
      age:     form.age.value,
      gender:  form.gender.value,
      phone:   form.phone.value.trim(),
      doctor:  form.selectDoctor.value,
      date:    form.apptDate.value,
      time:    form.apptTime.value,
      status:  'Confirmed'
    };

    const appts = getAppointments();
    appts.push(appt);
    saveAppointments(appts);

    const toast = document.getElementById('bookingToast');
    if (toast) { toast.classList.add('show'); toast.scrollIntoView({ behavior: 'smooth' }); }
    form.reset();
    populateDoctorSelect(); // re-apply pre-selection
  });
}

// ─── Render Appointments Table ───────────────────────────────
function renderAppointments() {
  const tbody = document.getElementById('apptTbody');
  const countEl = document.getElementById('apptCount');
  if (!tbody) return;

  const appts = getAppointments();
  if (countEl) countEl.textContent = appts.length;

  if (appts.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6">
      <div class="empty-state">
        <div class="empty-icon">📋</div>
        <p>No appointments booked yet. <a href="appointment.html" style="color:var(--primary)">Book your first one →</a></p>
      </div>
    </td></tr>`;
    return;
  }

  tbody.innerHTML = appts.map(a => `
    <tr>
      <td><strong>${a.patient}</strong></td>
      <td>${a.doctor}</td>
      <td>${formatDate(a.date)}</td>
      <td>${formatTime(a.time)}</td>
      <td>
        <span class="status-badge ${a.status === 'Confirmed' ? 'status-confirmed' : 'status-cancelled'}">
          ${a.status === 'Confirmed' ? '✓' : '✗'} ${a.status}
        </span>
      </td>
      <td>
        ${a.status === 'Confirmed'
          ? `<button class="btn btn-danger" onclick="cancelAppointment(${a.id})">Cancel</button>`
          : '<span style="color:var(--text-muted);font-size:.8rem">—</span>'}
      </td>
    </tr>
  `).join('');
}

function cancelAppointment(id) {
  if (!confirm('Are you sure you want to cancel this appointment?')) return;
  const appts = getAppointments().map(a => a.id === id ? { ...a, status: 'Cancelled' } : a);
  saveAppointments(appts);
  renderAppointments();
}

function clearAll() {
  if (!confirm('Delete ALL appointment records?')) return;
  saveAppointments([]);
  renderAppointments();
}

function formatDate(d) {
  if (!d) return '—';
  const [y, m, day] = d.split('-');
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return `${day} ${months[+m - 1]} ${y}`;
}

function formatTime(t) {
  if (!t) return '—';
  const [h, m] = t.split(':');
  const hNum = parseInt(h);
  return `${hNum % 12 || 12}:${m} ${hNum >= 12 ? 'PM' : 'AM'}`;
}

// ─── Contact Form ────────────────────────────────────────────
function setupContactForm() {
  const form = document.getElementById('contactForm');
  if (!form) return;
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    const toast = document.getElementById('contactToast');
    if (toast) { toast.classList.add('show'); toast.scrollIntoView({ behavior: 'smooth' }); }
    form.reset();
  });
}

// ─── Doctor Search / Filter ──────────────────────────────────
function setupSearch() {
  const input = document.getElementById('searchInput');
  const filterBtns = document.querySelectorAll('.filter-btn');
  let activeFilter = 'All';

  function applyFilter() {
    const query = input ? input.value.toLowerCase() : '';
    let list = doctors;
    if (activeFilter !== 'All') list = list.filter(d => d.specialty === activeFilter);
    if (query) list = list.filter(d =>
      d.name.toLowerCase().includes(query) ||
      d.specialty.toLowerCase().includes(query) ||
      d.location.toLowerCase().includes(query)
    );
    renderDoctors(list, 'doctorsGrid');
  }

  if (input) input.addEventListener('input', applyFilter);

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeFilter = btn.dataset.filter;
      applyFilter();
    });
  });
}

// ─── Home search ─────────────────────────────────────────────
function setupHomeSearch() {
  const btn = document.getElementById('heroSearchBtn');
  if (!btn) return;
  btn.addEventListener('click', () => {
    const q = document.getElementById('heroSearch')?.value || '';
    window.location.href = `doctors.html?q=${encodeURIComponent(q)}`;
  });

  // Apply query from URL on doctors page
  const params = new URLSearchParams(window.location.search);
  const q = params.get('q');
  const searchInput = document.getElementById('searchInput');
  if (q && searchInput) {
    searchInput.value = q;
  }
}

// ─── Nav mobile toggle ───────────────────────────────────────
function setupNav() {
  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', () => links.classList.toggle('open'));
  }

  // Active link highlight
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    if (a.getAttribute('href') === path) a.classList.add('active');
  });
}

// ─── Init ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  setupNav();
  setupHomeSearch();
  setupSearch();
  renderDoctors(doctors, 'doctorsGrid');
  populateDoctorSelect();
  setupBookingForm();
  renderAppointments();
  setupContactForm();

  // Home page: show 4 doctors
  const homeGrid = document.getElementById('homeDoctorsGrid');
  if (homeGrid) {
    renderDoctors(doctors.slice(0, 4), 'homeDoctorsGrid');
  }

  // Set min date for appointment
  const dateInput = document.getElementById('apptDate');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.min = today;
  }
});
